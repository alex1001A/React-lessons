export const testUsers = [
    { id: 1, name: "User 1", age: 25, email: "user1@example.com" },
    { id: 2, name: "User 2", age: 30, email: "user2@example.com" },
    { id: 3, name: "User 3", age: 22, email: "user3@example.com" },
    { id: 4, name: "User 4", age: 27, email: "user4@example.com" },
    { id: 5, name: "User 5", age: 29, email: "user5@example.com" }
];

export const testUsers2 = [
    { id: 1, name: "User 1", age: 25, email: "user1@example.com" },
    { id: 2, name: "User 2", age: 30, email: "user2@example.com" },
    { id: 3, name: "User 3", age: 22, email: "user3@example.com" },
    { id: 4, name: "User 4", age: 27, email: "user4@example.com" },
    { id: 5, name: "User 5", age: 29, email: "user5@example.com" }
];

export const testUsers3 = [
    { id: 1, name: "User 1", age: 25, email: "user1@example.com" },
    { id: 2, name: "User 2", age: 30, email: "user2@example.com" },
    { id: 3, name: "User 3", age: 22, email: "user3@example.com" },
    { id: 4, name: "User 4", age: 27, email: "user4@example.com" },
    { id: 5, name: "User 5", age: 29, email: "user5@example.com" }
];

export const testUsers4 = [
    { id: 1, name: "User 1", age: 25, email: "user1@example.com" },
    { id: 2, name: "User 2", age: 30, email: "user2@example.com" },
    { id: 3, name: "User 3", age: 22, email: "user3@example.com" },
    { id: 4, name: "User 4", age: 27, email: "user4@example.com" },
    { id: 5, name: "User 5", age: 29, email: "user5@example.com" }
];