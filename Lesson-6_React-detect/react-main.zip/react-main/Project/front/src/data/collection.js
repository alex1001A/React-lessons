export const CollectionAPI = [
    {
        name: 'Uromastyx Ornate',
        availability: 'In stock',
        image: './images/collection/image-1.png'
    },
    {
        name: 'Uromastyx Ornate',
        availability: 'In stock',
        image: './images/collection/image-2.png'
    },
    {
        name: 'Uromastyx Ornate',
        availability: 'In stock',
        image: './images/collection/image-3.png'
    },
    {
        name: 'Uromastyx Ornate',
        availability: 'In stock',
        image: './images/collection/image-4.png'
    },
    {
        name: 'Uromastyx Ornate',
        availability: 'In stock',
        image: './images/collection/image-1.png'
    },
    {
        name: 'Uromastyx Ornate',
        availability: 'In stock',
        image: './images/collection/image-6.png'
    },
    {
        name: 'Uromastyx Ornate',
        availability: 'In stock',
        image: './images/collection/image-7.png'
    },
    {
        name: 'Uromastyx Ornate',
        availability: 'In stock',
        image: './images/collection/image-8.png'
    },

]