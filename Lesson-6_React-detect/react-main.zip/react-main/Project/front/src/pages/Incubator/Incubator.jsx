export default function Incubator() {
    return (
        <h1>Incubator</h1>
    )
}